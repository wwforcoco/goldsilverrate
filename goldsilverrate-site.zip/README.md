# Gold Silver Rate - Pakistan

A simple static website showing the daily gold and silver (chandi) rate in Pakistan,
written in easy words for everyone to understand.

## How to update the daily rate (takes 1 minute)

1. Open `js/data.js`
2. Change these three numbers:

```js
updated: "14 November 2026, morning",   // today's date
gold24Tola: 415000,                     // today's 24K rate per tola
gold22Tola: 380500,                     // today's 22K rate per tola
silverTola: 5800                        // today's silver rate per tola
```

3. Save, commit and push. Every page, table and the calculator update automatically.

## Deploy on Cloudflare Pages

1. Cloudflare Dashboard -> Workers & Pages -> Create -> Pages -> Connect to Git
2. Select this repository
3. Build command: (leave empty)
4. Build output directory: `/`
5. Deploy

The site goes live on `https://goldsilverrate.pages.dev`.

## Pages

- `index.html` - homepage with both rates
- `gold-rate-today.html`, `silver-rate-today.html` - main rate pages
- `gold-rate-karachi.html`, `gold-rate-lahore.html`, `gold-rate-islamabad.html` - city pages
- `1-tola-gold-price.html`, `silver-bars-guide.html` - weight and bar guides
- `calculator.html` - live rate calculator
- `gold-buying-tips.html`, `24k-vs-22k-gold.html`, `how-gold-rate-is-set.html` - guides
- `about.html`, `contact.html`, `privacy-policy.html`, `disclaimer.html` - trust pages

## Before applying for AdSense

- Replace `your-email@gmail.com` in `contact.html` with a real email address.
- After deployment, submit the sitemap in Google Search Console.
- Update the rate daily - fresh content builds trust with both readers and ad reviewers.
