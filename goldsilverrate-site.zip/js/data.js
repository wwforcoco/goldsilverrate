/* ============================================================
   DAILY RATES - THIS IS THE ONLY FILE YOU EDIT EVERY DAY
   Change the three numbers below once per day, save, and push.
   Everything on the website updates automatically.
   ============================================================ */

var RATES = {
  updated: "13 November 2026, morning",
  gold24Tola: 415000,   // 24K gold price per tola (Rs)
  gold22Tola: 380500,   // 22K gold price per tola (Rs)
  silverTola: 5800      // 999 fine silver price per tola (Rs)
};

/* 1 tola = 11.6638 grams (do not change) */
var TOLA_GRAMS = 11.6638;

function getRate(key) {
  var r = RATES;
  switch (key) {
    /* Gold 24K */
    case "g24t":    return r.gold24Tola;
    case "g24t05":  return r.gold24Tola / 2;
    case "g24t2":   return r.gold24Tola * 2;
    case "g24g":    return r.gold24Tola / TOLA_GRAMS;
    case "g24t10":  return (r.gold24Tola / TOLA_GRAMS) * 10;
    /* Gold 22K */
    case "g22t":    return r.gold22Tola;
    case "g22t05":  return r.gold22Tola / 2;
    case "g22t2":   return r.gold22Tola * 2;
    case "g22g":    return r.gold22Tola / TOLA_GRAMS;
    case "g22t10":  return (r.gold22Tola / TOLA_GRAMS) * 10;
    /* Gold 21K (calculated from 24K) */
    case "g21t":    return (r.gold24Tola * 21) / 24;
    case "g21t10":  return ((r.gold24Tola * 21) / 24 / TOLA_GRAMS) * 10;
    case "g21g":    return ((r.gold24Tola * 21) / 24) / TOLA_GRAMS;
    /* Gold 18K (calculated from 24K) */
    case "g18t":    return (r.gold24Tola * 18) / 24;
    case "g18t10":  return ((r.gold24Tola * 18) / 24 / TOLA_GRAMS) * 10;
    case "g18g":    return ((r.gold24Tola * 18) / 24) / TOLA_GRAMS;
    /* Silver */
    case "st":      return r.silverTola;
    case "sg":      return r.silverTola / TOLA_GRAMS;
    case "st10":    return (r.silverTola / TOLA_GRAMS) * 10;
    /* Silver bulk amounts */
    case "st5tola":  return r.silverTola * 5;
    case "st10tola": return r.silverTola * 10;
    case "st52tola": return r.silverTola * 52;
    case "s1kg":     return (r.silverTola / TOLA_GRAMS) * 1000;
    /* Gold bars */
    case "g24t10tola": return r.gold24Tola * 10;
    default: return 0;
  }
}
