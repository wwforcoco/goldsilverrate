/* Gold Silver Rate - renders rates everywhere + calculator */

function fmt(n) {
  return Math.round(n).toLocaleString("en-US");
}

function getMetalPerGram(key) {
  switch (key) {
    case "g24": return getRate("g24g");
    case "g22": return getRate("g22g");
    case "g21": return getRate("g21g");
    case "g18": return getRate("g18g");
    case "silver": return getRate("sg");
    default: return 0;
  }
}

document.addEventListener("DOMContentLoaded", function () {

  /* 1. Fill every element that shows a rate */
  var nodes = document.querySelectorAll("[data-r]");
  for (var i = 0; i < nodes.length; i++) {
    var el = nodes[i];
    var v = getRate(el.getAttribute("data-r"));
    if (v > 0) el.textContent = fmt(v);
  }

  /* 2. Fill "last updated" text */
  var up = document.querySelectorAll("[data-updated]");
  for (var j = 0; j < up.length; j++) {
    up[j].textContent = RATES.updated;
  }

  /* 3. Footer year */
  var yr = document.querySelectorAll("[data-year]");
  for (var k = 0; k < yr.length; k++) {
    yr[k].textContent = new Date().getFullYear();
  }

  /* 4. Calculator */
  var wInput = document.getElementById("calc-w");
  var uSelect = document.getElementById("calc-u");
  var mSelect = document.getElementById("calc-m");
  var goBtn = document.getElementById("calc-go");
  var out = document.getElementById("calc-out");

  function runCalc() {
    if (!wInput || !out) return;
    var w = parseFloat(wInput.value);
    if (!w || w <= 0) {
      out.hidden = true;
      return;
    }
    var unit = uSelect.value;
    var grams = (unit === "tola") ? w * TOLA_GRAMS : w;
    var tolas = (unit === "tola") ? w : w / TOLA_GRAMS;
    var perGram = getMetalPerGram(mSelect.value);
    var value = grams * perGram;
    var metalName = mSelect.options[mSelect.selectedIndex].text;

    document.getElementById("calc-value").textContent = "Rs " + fmt(value);
    document.getElementById("calc-line1").textContent =
      w + " " + (unit === "tola" ? (w === 1 ? "tola" : "tola") : (w === 1 ? "gram" : "grams")) +
      " = " + grams.toFixed(2) + " grams = " + tolas.toFixed(3) + " tola";
    document.getElementById("calc-line2").textContent =
      metalName + " at the board rate shown on this page. Jewellers add making charges on top for jewellery.";
    out.hidden = false;
  }

  if (goBtn) {
    goBtn.addEventListener("click", runCalc);
    [wInput, uSelect, mSelect].forEach(function (el) {
      el.addEventListener("change", runCalc);
      el.addEventListener("input", runCalc);
    });
  }
});
